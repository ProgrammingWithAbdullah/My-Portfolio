document.addEventListener("DOMContentLoaded", function () {
  const skillsSelect = document.getElementById("skillsSelect");
  const selectedSkillsList = document.getElementById("selectedSkillsList");

  skillsSelect.addEventListener("change", function () {
    Array.from(this.selectedOptions).forEach((option) => {
      const listItem = document.createElement("li");
      listItem.textContent = option.textContent;
      selectedSkillsList.appendChild(listItem);

      selectedSkillsList.scrollTop = selectedSkillsList.scrollHeight;
    });
  });

  function validateFullName() {
    var fname = document.getElementById("fname").value;
    var lname = document.getElementById("lname").value;

    if (fname.trim() == "" || lname.trim() == "") {
      alert("Please enter both first name and last name.");
      return false;
    }

    return true;
  }
  function validateContactInfo() {
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;

    // Email format validation using regular expression
    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      alert("Please enter a valid email address.");
      return false;
    }

    // Phone number format validation
    var phonePattern = /^\d{10}$/; // Assuming 10-digit phone number
    if (!phonePattern.test(phone)) {
      alert("Please enter a valid 10-digit phone number.");
      return false;
    }

    return true;
  }
  function validateJobDates() {
    var startDate = new Date(document.getElementById("startDate").value);
    var endDate = new Date(document.getElementById("endDate").value);

    // Check if start date is before end date
    if (startDate >= endDate) {
      alert("End date must be after start date.");
      return false;
    }

    return true;
  }
});
