document.addEventListener("DOMContentLoaded", function () {
  var btn1 = document.getElementById("btn1");
  var btn2 = document.getElementById("btn2");
  var btn3 = document.getElementById("btn3");
  var btn4 = document.getElementById("btn4");
  var btn5 = document.getElementById("btn5");
  var btn6 = document.getElementById("btn6");
  var b1 = document.getElementById("b1");
  var b2 = document.getElementById("b2");
  var b3 = document.getElementById("b3");
  var b4 = document.getElementById("b4");
  var mainimg = document.getElementById("mainimg");
  var scont = document.getElementById("scont");

  var functions = [
    function1,
    function2,
    function3,
    function4,
    function5,
    function6,
  ];
  var index = 0;
  var intervalId = setInterval(callFunction, 5000);

  function callFunction() {
    functions[index]();
    index = (index + 1) % functions.length;
  }

  btn1.addEventListener("click", function1);
  function function1() {
    resetButtonColors();
    mainimg.innerHTML = '<img src="img.jpg" alt="Circular Image" />';
    b1.innerHTML = "branding";
    b2.innerHTML = "business";
    b3.innerHTML = "logo";
    b4.innerHTML = "cardsvector";
    btn1.style.backgroundColor = "orange";
    document.getElementById("intext1").style.color = "blue";
    document.getElementById("marr").innerHTML = "Try Web Development";
    document.querySelector(".cont1").style.backgroundColor = "blue";
  }

  btn2.addEventListener("click", function2);
  function function2() {
    resetButtonColors();
    scont.innerHTML = `<div style="margin-left: 10px"><b>Digital Marketer</b></div>
      <div style="margin-left: 30px">Lee Yen</div>`;
    mainimg.innerHTML = '<img src="img.jpg" alt="Circular Image" />';
    b1.innerHTML = "link";
    b2.innerHTML = "buildingadwords";
    b3.innerHTML = "web dev";
    b4.innerHTML = "web designs";
    btn2.style.backgroundColor = "orange";
    document.getElementById("intext1").style.color = "pink";
    document.getElementById("marr").innerHTML = "Try E-commerce";
    document.querySelector(".cont1").style.backgroundColor = "pink";
  }

  btn3.addEventListener("click", function3);
  function function3() {
    resetButtonColors();
    scont.innerHTML = `
      <div style="margin-left: 10px">
        <b>Logo Designer</b>
      </div>
      <div style="margin-left: 30px">Mark Henry</div>`;
    mainimg.innerHTML = '<img src="img.jpg" alt="Circular Image" />';
    b1.innerHTML = "amazon store management";
    b2.innerHTML = "cms development";
    b3.innerHTML = "wordpress development";
    b4.innerHTML = "php";
    btn3.style.backgroundColor = "orange";
    document.getElementById("intext1").style.color = "orange";
    document.getElementById("marr").innerHTML = "Try Logo Design";
    document.querySelector(".cont1").style.backgroundColor = "orange";
  }

  btn4.addEventListener("click", function4);
  function function4() {
    resetButtonColors();
    scont.innerHTML = `
      <div style="margin-left: 10px">
      <b>Graphic Designer</b>
      </div>`;
    mainimg.innerHTML = '<img src="img.jpg" alt="Circular Image" />';
    b1.innerHTML = "databases";
    b2.innerHTML = "logo";
    b3.innerHTML = "designs";
    b4.innerHTML = "animation 3D";
    btn4.style.backgroundColor = "orange";
    document.getElementById("intext1").style.color = "violet";
    document.getElementById("marr").innerHTML = "Try Graphic Design";
    document.querySelector(".cont1").style.backgroundColor = "violet";
  }

  btn5.addEventListener("click", function5);
  function function5() {
    resetButtonColors();
    scont.innerHTML = `
      <div style="margin-left: 10px">
        <b>Web Developer</b>
      </div>
      <div style="margin-left: 30px">Tyson Yolk</div>`;
    mainimg.innerHTML = '<img src="img.jpg" alt="Circular Image" />';
    b1.innerHTML = "amazon store management";
    b2.innerHTML = "cms development";
    b3.innerHTML = "wordpress development";
    b4.innerHTML = "php";
    btn5.style.backgroundColor = "orange";
    document.getElementById("intext1").style.color = "red";
    document.getElementById("marr").innerHTML = "Try Web Development";
    document.querySelector(".cont1").style.backgroundColor = "red";
  }

  btn6.addEventListener("click", function6);
  function function6() {
    resetButtonColors();
    scont.innerHTML = `
      <div style="margin-left: 10px">
        <b>Graphic Designer</b>
      </div>
      <div style="margin-left: 30px">Jennifer bez</div>`;
    mainimg.innerHTML = '<img src="img.jpg" alt="Circular Image" />';
    b1.innerHTML = "web design";
    b2.innerHTML = "ux/ui design";
    b3.innerHTML = "android app development";
    b4.innerHTML = "responsive design";
    btn6.style.backgroundColor = "orange";
    document.getElementById("intext1").style.color = "brown";
    document.getElementById("marr").innerHTML = "Try Graphic Design";
    document.querySelector(".cont1").style.backgroundColor = "brown";
  }

  function resetButtonColors() {
    btn1.style.backgroundColor = "";
    btn2.style.backgroundColor = "";
    btn3.style.backgroundColor = "";
    btn4.style.backgroundColor = "";
    btn5.style.backgroundColor = "";
    btn6.style.backgroundColor = "";
  }
});
